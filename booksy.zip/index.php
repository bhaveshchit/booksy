<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index1121</title>




</head>


<body>
    <?php
    require_once('connectvars.php');
    require_once('startsession.php');
    require_once('nav.php');
    require_once('popup.php');
    ?>
    <br>
    <br>
    <div class="container-fluid text-center" id="new">
        <div class="row">
            <div class="col-sm-6 col-md-3 col-lg-3">
                <a href="description.php?ID=NEW-1&category=new">
                    <div class="book-block">
                        <div class="tag">New</div>
                        <div class="tag-side"><img src="img/tag.png"></div>
                        <img class="book block-center img-responsive" src="img/new/1.jpg">
                        <hr>
                        Like A Love Song <br>
                        Rs 113 &nbsp
                        <span style="text-decoration:line-through;color:#828282;"> 175 </span>
                        <span class="label label-warning">35%</span>
                    </div>
                </a>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <a href="description.php?ID=NEW-2&category=new">
                    <div class="book-block">
                        <div class="tag">New</div>
                        <div class="tag-side"><img src="img/tag.png"></div>
                        <img class="block-center img-responsive" src="img/new/2.jpg">
                        <hr>
                        General Knowledge 2017 <br>
                        Rs 68 &nbsp
                        <span style="text-decoration:line-through;color:#828282;"> 120 </span>
                        <span class="label label-warning">43%</span>
                    </div>
                </a>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <a href="description.php?ID=NEW-3&category=new">
                    <div class="book-block">
                        <div class="tag">New</div>
                        <div class="tag-side"><img src="img/tag.png"></div>
                        <img class="block-center img-responsive" src="img/new/3.png">
                        <hr>
                        Indian Family Bussiness Mantras <br>
                        Rs 400 &nbsp
                        <span style="text-decoration:line-through;color:#828282;"> 595 </span>
                        <span class="label label-warning">33%</span>
                    </div>
                </a>
            </div>
            <div class="col-sm-6 col-md-3 col-lg-3">
                <a href="description.php?ID=NEW-4&category=new">
                    <div class="book-block">
                        <div class="tag">New</div>
                        <div class="tag-side"><img src="img/tag.png"></div>
                        <img class="block-center img-responsive" src="img/new/4.jpg">
                        <hr>
                        Kiran s SSC Mathematics Chapterwise Solutions <br>
                        Rs 289 &nbsp
                        <span style="text-decoration:line-through;color:#828282;"> 435 </span>
                        <span class="label label-warning">33%</span>
                    </div>
                </a>
            </div>
        </div>
    </div>




    <br>
    <br><br><br>
    <?php
    require_once('footer.php');
    require_once('footer1.php');
    require_once('ask.php');
    require_once('cookie.php');

    ?>


</body>

</html>