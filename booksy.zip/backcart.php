<script>
    alert("Dont refresh page");
</script>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>confirm</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>


<?php


require_once('startsession.php');
require_once('nav.php');
include_once('dbconnect.php');


?>











<?php


if (isset($_GET['remove'])) {
    $product = $_GET['remove'];


    $query = "SELECT *FROM cart where Product='$product'";
    $result = mysqli_query($con, $query);
    if (mysqli_num_rows($result)  > 0) {
        $row = mysqli_fetch_array($result);

        $customer = $row['Customer'];
        $product = $row['Product'];
        $quantity = $row['Quantity'];
        $sub_query = "SELECT PID,Title,Author,Edition,Quantity,Price FROM cart INNER JOIN products ON cart.Product=products.PID 
              	        WHERE Customer='$customer'";
        $result = mysqli_query($con, $sub_query);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $Stotal = $row['Quantity'] * $row['Price'];
                $qua = $row['Quantity'];





                echo '
                    <br><br><br>
                    <table class="table">
                    <tr>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                
                    <tr>
                        <td>' . $row['Title'] . '</td>
                        <td>' . $row['Price']  . '</td>
                        <td>' .  $row['Quantity']  . '</td>
                        <td>' . $Stotal . '</td>
                    </tr>
                    <tr>
                        <th>&nbsp;</th>
                        <th>&nbsp;</th>
                        <th>' .  $row['Quantity']  . '</th>
                        <th>' . $Stotal . '</th>
                    </tr>
                </table>';







                $ass = $_SESSION['username'];
                $query12 = "SELECT *from user_info where username = '$customer'";
                $result = mysqli_query($con, $query12);

                if (mysqli_num_rows($result) > 0) {
                    $row = mysqli_fetch_array($result);

                    $n = $row['full_name'];
                    $a = $row['address'];
                    $c = $row['city'];
                    $s = $row['state'];
                    $nu = $row['number'];
                }



?>




                <div class="container">

                    <div class="card-columns">
                        <div class="card bg-light">
                            <div class="card-body text-center">

                                <p class="card-text">

                                    <strong style="text-align: center;">ADDRESS</strong><br>
                                    Name: <?php echo "$n";  ?><br>
                                    Contact: <?php echo "$nu"; ?><br>
                                    Address: <?php echo "$a"; ?><br>
                                    City: <?php echo "$c"; ?><br><br><br>


                                </p>
                            </div>
                        </div>
                    </div>
                </div>




<?php


                echo "<br><br><br>";









                $fire_query = "INSERT INTO order_info (pid,customer,price,status,quantity) values('$product','$customer','$Stotal','pending',$qua)";
                $fire = mysqli_query($con, $fire_query);






                $j_query = "SELECT * from order_info where pid = '$product' and customer = '$customer' and status = 'pending'";
                $j_result = mysqli_query($con, $j_query);





                if (mysqli_num_rows($j_result) > 0) {
                    while ($j_row = mysqli_fetch_assoc($j_result)) {
                        $target = "paytm.php?place_id=" . $j_row["order_id"];
                        $target1 = "cod.php?place_id=" . $j_row["order_id"];





                        echo '
    <a href="' . $target . '" class="btn btn-sm" 
    style="background:black;color:white;font-weight:10px;">
    online order
  </a>';

                        echo '
  <a href="' . $target1 . '" class="btn btn-sm" 
  style="background:black;color:white;font-weight:10px;">
  cod order
</a>';
                    }
                }









                //kjxc hj





            }
        }
    }
}

?>