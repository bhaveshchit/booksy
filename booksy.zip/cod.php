<?php


include_once('dbconnect.php');




if (isset($_GET['place_id'])) {

    $order_id = $_GET['place_id'];




    $updatequery = "UPDATE order_info SET method = 'cod'  WHERE order_id = '$order_id'";
    $query = mysqli_query($con, $updatequery);
    $updatequery1 = "UPDATE order_info SET status = 'success'  WHERE order_id = '$order_id'";
    $query = mysqli_query($con, $updatequery1);



    $query  = "SELECT * from order_info where order_id = '$order_id'";
    $result = mysqli_query($con, $query);
    if (mysqli_num_rows($result)  > 0) {
        $row = mysqli_fetch_array($result);
        $price = $row['price'];
        $customer = $row['customer'];
    }




    $email_query = "SELECT email from booksy_user where username = '$customer'";
    $result = mysqli_query($con, $email_query);

    if (mysqli_num_rows($result) == 1) {
        $data = mysqli_fetch_array($result);
        $r_email = $data['email'];
    }






    $to_email = $r_email;
    $subject = "Order Placed";
    $body = "Hi $customer, Your order has been placed. your order-id: $order_id and your books worth of Rs.$price is on the way. THANKS FOR THE SHOPPING";
    $headers = "From: sedvick99@gmail.com";

    if (mail($to_email, $subject, $body, $headers)) {
?>
        <script>
            alert("check your email, your order has been placed,thanks for shopping with us");
        </script>



<?php
        echo '
 <a href="index.php">
 Back to home
</a>';
    } else {
        echo "Email sending failed...";
    }



    $b_query = "DELETE  from cart where Customer = '$customer'  ";
    mysqli_query($con, $b_query);
}
?>