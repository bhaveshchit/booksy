<?php


require_once('startsession.php');
include_once('dbconnect.php');


if (isset($_SESSION['username'])) {

    if (isset($_GET['place_id'])) {

        $order_id = $_GET['place_id'];



        $updatequery = "UPDATE order_info SET method = 'online' WHERE order_id = '$order_id'";
        $query = mysqli_query($con, $updatequery);


        $query  = "SELECT * from order_info where order_id = '$order_id'";
        $result = mysqli_query($con, $query);
        if (mysqli_num_rows($result)  > 0) {
            $row = mysqli_fetch_array($result);
            $uid = $row['customer'];
            $amount = $row['price'];
        }
    }
}
?>

<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");
$html = '<form method="post" action="pgRedirect.php" name="frmpayment"
style = "display:none;">
<input id="ORDER_ID" tabindex="1" maxlength="20" size="20" name="ORDER_ID" autocomplete="off" value="' . $order_id . '">
<input id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="' . $uid . '"></td>
<input id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail"></td>
<input id="CHANNEL_ID" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
<input title="TXN_AMOUNT" tabindex="10" type="text" name="TXN_AMOUNT" value="' . $amount . '">
<input value="CheckOut" type="submit" onclick=""></td>
        
</form><script type="text/javascript">
document.frmpayment.submit();
</script>';
echo $html;

?>