<?php
// Define application constants
define('MM_UPLOADPATH', 'images/');
define('MM_MAXFILESIZE', 6250000);      // 5 mb
define('MM_MAXIMGWIDTH', 12000);        // 600 pixels
define('MM_MAXIMGHEIGHT', 12000);       // 600 pixels
